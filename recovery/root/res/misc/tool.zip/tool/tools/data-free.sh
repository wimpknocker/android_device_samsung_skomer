#!/sbin/sh

# Ketut P. Kumajaya: May 2013, Nov 2013, Apr 2014, Sept 2014

# Import dual boot environment setup
. /res/misc/env.sh

if [ $(/sbin/busybox mount | grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

FREESPACE=0
if [ $(/sbin/busybox mount | grep -c "/.secondrom") -eq 1 ]; then
  FREESPACE=$(df | grep "/.secondrom" | awk '{printf $3}')
else
  FREESPACE=$(df | grep "/data" | awk '{printf $3}')
fi

# Extra space from system.img
if [ -f /data/media/.secondrom/system.img ]; then
  FREESPACE=$(($FREESPACE + $(ls -s /data/media/.secondrom/system.img | awk '{printf $1}')))
fi

if [ $FREESPACE -lt $DATAFREESPACE ]; then
  exit 1
fi

exit 0
